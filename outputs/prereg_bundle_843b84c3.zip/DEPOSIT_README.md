> **PRE-FREEZE DRY-RUN** — `frozen: false` at bundle time. Re-run this script AFTER
> `scripts/freeze.py` records the freeze; only a post-freeze bundle should be deposited.

# Pre-registration deposit bundle

Frozen design of the dissertation *LLM-designed reward code under distributional (tail)
feedback for risk-sensitive portfolio RL* — the exact byte content bound by the freeze hash.

* canonical SHA-256: `843b84c34b5fdbd90b260d0d96f78fd909fa3528d13309d4c44339d7bb2387c0`
* recorded freeze_hash: `None`
* frozen: `False`

## How to deposit (one-time, at freeze)

1. Create an OSF project (osf.io) titled with the dissertation title; upload this zip.
2. Create an OSF **Registration** of the project (the frozen, timestamped snapshot).
3. Record the OSF DOI/URL + date in `DECISIONS.md` and cite it in the PDF (CH4 SS4.8):
   "pre-registered and frozen on <date>; OSF <link>; SHA-256 <hash>".
4. Alternative/additional anchor: push the `prereg-v1.0` git tag to the public remote and
   create a dated GitHub release attaching this zip.
